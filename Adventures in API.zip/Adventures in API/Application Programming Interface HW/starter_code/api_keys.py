# OpenWeatherMap API Key
api_key = "734101d89b01c4203d11bb03f1960e5d"


